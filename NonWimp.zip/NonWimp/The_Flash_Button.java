/*
 *  The_Flash_Button.java
 *  Kevin Aka
 *  12-10-23
 *
 *  CS 86 NonWimp
 * 
 * 
 */

import javax.swing.JButton;

public class The_Flash_Button extends JButton{
    public The_Flash_Button(){
        
    }
}
